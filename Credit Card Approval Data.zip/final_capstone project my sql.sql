SELECT Ind_id from final_project;
SELECT MyUnknownColumn  AS row_no FROM final_project;


##Q1.Group the customers based on their income type and find the average of their annual income?
SELECT Type_Income, AVG(Annual_income) AS Avg_Annual_Income
FROM final_project
GROUP BY Type_Income;

##Q2.Find the female owners of cars and property.
SELECT Ind_id, Gender, Car_Owner, Propert_Owner
FROM final_project
WHERE Gender = 'F' AND Car_Owner = 'Y' AND Propert_Owner = 'Y';

##Q3.Find the male customers who are staying with their families.
SELECT Ind_id,Gender,Family_Members FROM final_project
WHERE Gender = 'M' AND Family_Members > 1;

##Q4.Please list the top five people having the highest income.
SELECT *FROM final_project
ORDER BY Annual_income DESC
LIMIT 5;


##Q5.How many married people are having bad credit?
SELECT COUNT(*) AS bad_credit
FROM final_project
WHERE Marital_status = 'Married' AND label = 0;

##Q6.What is the highest education level and what is the total count?
SELECT Education, COUNT(*) AS education_count
FROM final_project
GROUP BY Education
ORDER BY education_count DESC
LIMIT 1;

##Q7.Between married males and females, who is having more bad credit? 
SELECT Gender,
    SUM(CASE WHEN Marital_status = 'Married' AND label = 0 THEN 1 ELSE 0 END) AS bad_credit
FROM final_project
WHERE Marital_status = 'Married'
GROUP BY Gender;



